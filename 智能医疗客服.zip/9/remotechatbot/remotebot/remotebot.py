from botbuilder.core import TurnContext,ActivityHandler,MessageFactory
from botbuilder.ai.qna import QnAMaker,QnAMakerEndpoint


class RemoteBot(ActivityHandler):
    def __init__(self):
       endpoint = QnAMakerEndpoint("d523e53f-7827-41d0-b87a-30d790a30588","1aa8870b-0bd6-4c28-862e-e287986db384","https://remote-chatbot.azurewebsites.net/qnamaker")
       self.botmaker = QnAMaker(endpoint)

    async def on_message_activity(self,context:TurnContext):
      response = await self.botmaker.get_answers(context)
      if response and len(response) > 0:
         await context.send_activity(MessageFactory.text(response[0].answer))
