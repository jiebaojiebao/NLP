from flask import Flask,request,Response
from botbuilder.core import BotFrameworkAdapter
from botbuilder.core import BotFrameworkAdapterSettings
from botbuilder.core import TurnContext
from botbuilder.core import ConversationState
from botbuilder.core import MemoryStorage
from botbuilder.schema import Activity
from remotebot import RemoteBot
import asyncio

app = Flask(__name__)
loop = asyncio.get_event_loop()

botframework = BotFrameworkAdapterSettings("","")
botadapter = BotFrameworkAdapter(botframework)

#CONMEMORY = ConversationState(MemoryStorage())
remotebot = RemoteBot()


@app.route("/api/messages",methods=["POST"])
def messages():
    if "application/json" in request.headers["content-type"]:
        context = request.json
    else:
        return Response(status = 415)

    activity = Activity().deserialize(context)
    
    if "Authorization" in request.headers:
        
        outcome = request.headers["Authorization"]  
    
    else: 
        outcome=""

    async def call_fun(turncontext):
        await remotebot.on_turn(turncontext)

    task = loop.create_task(
        botadapter.process_activity(activity,outcome,call_fun)
        )
    loop.run_until_complete(task)


if __name__ == '__main__':
    app.run('localhost',4000)
