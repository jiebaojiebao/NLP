#coding:utf-8
import logging
import jieba
import pickle
from fuzzywuzzy import fuzz
import math
from scipy import sparse
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from scipy.sparse import lil_matrix
from sklearn.naive_bayes import MultinomialNB
import warnings
import csv
import logging
from tkinter import *
import time
import difflib
from collections import Counter
import numpy as np




def display_response(outcome1,outcome2):
    
    if outcome1 is not None:
        outcome = outcome1
    
    elif outcome2 is not None:
        outcome = outcome2


    else:
        outcome = "非常抱歉，目前暂时没有搜索到与您的问题相匹配的答案，我们会继续关注您的问题，欢迎您下次继续光临。"
    return outcome


    
    
def cosine_similarity(text1, text2):        
    cos_text1 = (Counter(text1))
    cos_text2 = (Counter(text2))
    similarity_text1 = []
    similarity_text2 = []
    for i in set(text1 + text2):
        similarity_text1.append(cos_text1[i])
        similarity_text2.append(cos_text2[i])

    similarity_text1 = np.array(similarity_text1)
    similarity_text2 = np.array(similarity_text2)

    return similarity_text1.dot(similarity_text2) / (np.sqrt(similarity_text1.dot(similarity_text1)) * np.sqrt(similarity_text2.dot(similarity_text2)))

    
    
def greeting_response(msg,input_greet,output_greet):
    selection = {}
    for key, value in enumerate(input_greet):
        comparison = cosine_similarity(msg, value)
        if comparison > 0.6:
            selection[key] = comparison
        sort = sorted(selection.items(), key=lambda x: x[1], reverse=True)
    outcome = output_greet[sort[0][0]] if  len(selection) != 0 else None
    return  outcome
    
    
    
def prediction(message):
    input_greet = []
    output_greet = []
    with open("label.csv", 'r',encoding='utf-8') as df:
        greets = csv.reader(df)
        next(greets)
        for greet in greets:
            input_greet.append(greet[1])
            output_greet.append(greet[2])
            
    selection = {}
    for key, value in enumerate(input_greet):
        comparison = cosine_similarity(message, value)
        if comparison > 0.1:
            selection[key] = comparison
        sort = sorted(selection.items(), key=lambda x: x[1], reverse=True)
    outcome = output_greet[sort[0][0]] if  len(selection) != 0 else None
    return  outcome 

    
#根据用户输入信息输出响应处理
def entrance(msg):
    input_greet = []
    output_greet = []
    with open("greeting.csv", 'r',encoding='utf-8') as df:
        greets = csv.reader(df)
        next(greets)
        for greet in greets:
            input_greet.append(greet[0])
            output_greet.append(greet[1])
    outcome1 = greeting_response(msg,input_greet,output_greet)
    outcome2 = prediction(msg)
    outcome = display_response(outcome1,outcome2)
    return outcome

