#!/usr/bin/env python3
# _*_ coding:utf-8 _*_

#导入库文件
import time
import tkinter as tk
from tkinter import *
from tkinter import Tk 
from tkinter import  Text  
from tkinter import  Button 
from function import *
 

#设置智能客服应用界面风格
tk = Tk(screenName=None, baseName=None)
tk.title('智能医疗客服')
tk.geometry('500x600')
tk.resizable(True, True)


#定义用户提问和客服回答消息处理函数
def msgProcess():	
    #获取用户的输入信息
    msg = txt.get("1.0",'end-1c').strip()
    #删除用户的输入信息
    txt.delete("0.0",END)
    #定义用户消息和客服消息的颜色显示区分
    chatmsg.tag_config('question', background="white", foreground="blue")
    chatmsg.tag_config('answer', background="white", foreground="black")

    if msg != "":

		#获取和显示用户消息    
        tmsg = '【用户问题】 ' + time.strftime('%Y/%m/%d %H:%M', time.localtime()) + '\n'
        chatmsg.insert(END, tmsg, 'question')
        chatmsg.insert(END, msg + '\n\n','question')
        #根据用户的输入信息进行匹配操作
       
        outcome = entrance(msg)
        
        chatmsg.config(state=NORMAL)
        
        #获取和显示客服应答消息 
        botresponse = '【客服回答】 ' + time.strftime('%Y/%m/%d %H:%M', time.localtime()) + '\n'
        chatmsg.insert(END, botresponse, 'answer')
        chatmsg.insert(END, outcome + '\n\n', 'answer')
    else:
        tmsg = '用户问题:  ' + time.strftime('%Y/%m/%d %H:%M', time.localtime()) + '\n'
        chatmsg.insert(END, tmsg, 'question') 
        chatmsg.config(state=NORMAL)
        chatmsg.insert(END, msg + '\n\n','question')
        botresponse = '客服回答:  ' + time.strftime('%Y/%m/%d %H:%M', time.localtime()) + '\n'
        chatmsg.insert(END, botresponse, 'answer')
        chatmsg.insert(END, "对不起，我没有理解您的问题，请输入您要咨询的问题。"+'\n\n', 'answer')

# 取消发送消息
def msgCancel():
    txt.delete('0.0', END)  

chatmsg = Text(tk, borderwidth=0, cursor=None,state=NORMAL, background="white", height="12", width="70", font="kaiti",wrap=WORD)

#设置滚动条
srb = Scrollbar(tk, command=chatmsg.yview, activebackground=None,background="white",borderwidth=0,highlightcolor="purple",cursor="arrow",
jump=0,orient=VERTICAL,width=16,elementborderwidth=1)
srb.pack( side = RIGHT, fill = Y )
chatmsg['yscrollcommand'] = srb.set
chatmsg.see("end")

#设置信息输入框风格
txt = Text(tk, borderwidth=0, cursor=None,background="white",width="25", height="8", font="kaiti",wrap=WORD)

#设置发送消息按钮风格
msgBtnS = Button(tk, font=("kaiti",12,"bold"), text="提交咨询", width=12, height=8,highlightcolor=None,image=None,justify=CENTER,state=ACTIVE,
                    borderwidth=0, background="#111fed", activebackground="#524e78",foreground ='white',relief=RAISED,
                    command= msgProcess )
                    
msgBtnC = Button(tk, font=("kaiti",12,"bold"), text="取消咨询", width=12, height=8,highlightcolor=None,image=None,justify=CENTER,state=ACTIVE,
                    borderwidth=0, background="#111fed", activebackground="#524e78",foreground ='white',relief=RAISED,
                    command= msgCancel )

#显示组件内容

srb.place(relx=0.8, rely=0.35, relwidth=0.03, relheight=0.66, anchor='e')
chatmsg.place(relx=0.0, rely=0.35, relwidth=0.8, relheight=0.66, anchor='w')
txt.place(relx=0.002, rely=0.685, relwidth=0.8,relheight=0.2)
msgBtnS.place(bordermode=OUTSIDE,relx=0.1, rely=0.9, relwidth=0.2,relheight=0.05)
msgBtnC.place(bordermode=OUTSIDE,relx=0.4, rely=0.9, relwidth=0.2,relheight=0.05)

tk.mainloop()


