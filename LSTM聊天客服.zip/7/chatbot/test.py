#导入库
import nltk
import pickle as pk
import numpy as np
import json as js
import random

from tensorflow import keras
from tensorflow.keras.models import load_model
from nltk.stem import WordNetLemmatizer
wordlem = WordNetLemmatizer()
from tkinter import * 
from tkinter import  Text  
from tkinter import  Button  
import tkinter


#加载训练模型
load = load_model('data/model.h5')

#加载数据和中间结果
chatbot = js.loads(open('data/chatbot.json').read())
wordlist = pk.load(open('data/wordlist.pkl','rb'))
category = pk.load(open('data/category.pkl','rb'))


def tokenization(text):
    #分词
    word_tokens = nltk.word_tokenize(text)
    # 词形还原
    #for i in sw:
    word_tokens =  [wordlem.lemmatize(i.lower()) for i in word_tokens] 
    return word_tokens

#词袋模型
def bow(text, wordlist):
    #分词
    tokens = tokenization(text)
    bow = [0]*len(wordlist)  
    for token in tokens:
        for i,flag in enumerate(wordlist):
            if flag == token: 
                #查找匹配成功则标识为1
                bow[i] = 1
                print ("词袋模型匹配结果: %s" % flag)
    return(np.array(bow))

#预测结果
def predict(text, load):
    #设置阈值，过滤阈值以下内容
    err_level = 0.20
    outlist = []
    bow_outcome= bow(text,wordlist)
    result = load.predict(np.array([bow_outcome]))[0]
 
    #根据概率结果排序
    outcome = [[i,j] for i,j in enumerate(result) if j>err_level]
    outcome.sort(key=lambda x: x[1], reverse=True)
    for j in outcome:
        outlist.append({"k": category[j[0]], "probability": str(j[1])})
    return outlist

#设置应答信息
    
def getResponse(pred, intents_json):
    ptype = pred[0]['k']
    print("用户提问类型：",ptype)
    ctype = intents_json['chatbot']
    for type in  ctype:
        if(type['category']== ptype):
            result = random.choice(type['output'])
            print("提供给用户的响应信息：",result)
            break
    return result    


#预测消息响应
def chatbot_Response(query):
    pred = predict(query, load)
    outcome = getResponse(pred, chatbot)
    return outcome




#设置用户和智能客服之间的消息交互
def chatbotInteract():
    query = txt.get("1.0",'end-1c').strip()
    txt.delete("0.0",END)


    chatwnd.tag_config('question', background="white", foreground="black")
    chatwnd.tag_config('answer', background="white", foreground="blue")
    chatwnd.config(state=NORMAL)
    chatwnd.insert(END, "用户问题：\n" + query + '\n\n','question')

    outcome = chatbot_Response(query)
    chatwnd.insert(END, "客服回答：\n" + outcome + '\n\n','answer')   
        
    chatwnd.config(state=NORMAL)
    chatwnd.yview(END)


 
#设置智能客服应用界面风格
tk_window = tkinter.Tk(screenName=None, baseName=None)
tk_window.title("智能客服")
tk_window.geometry("500x600")
tk_window.resizable(False, False)

#设置文本框
chatwnd = Text(tk_window, borderwidth=2, cursor=None,state=NORMAL, background="white", height="12", width="70", font="Arial",wrap=WORD)

#设置滚动条
srb = Scrollbar(tk_window, command=chatwnd.yview, activebackground=None,background="white",borderwidth=2,highlightcolor="purple",cursor="arrow",
jump=0,orient=VERTICAL,width=16,elementborderwidth=1)
srb.pack( side = RIGHT, fill = Y )
chatwnd['yscrollcommand'] = srb.set


#设置信息输入框风格
txt = Text(tk_window, borderwidth=0, cursor=None,background="white",width="25", height="8", font="Arial",wrap=WORD)

#设置发送消息按钮风格
msgBtn = Button(tk_window, font=("kaiti",14), text="咨询", width=12, height=8,highlightcolor=None,image=None,justify=CENTER,state=ACTIVE,
                    borderwidth=0, background="Blue", activebackground="#524e78",fg ='white',relief=RAISED,
                    command= chatbotInteract )




#显示组件内容

srb.place(x=404,y=12, height=398)
chatwnd.place(relx=0.0, rely=0.35, relwidth=0.8, relheight=0.66, anchor='w')
msgBtn.place(bordermode=OUTSIDE,x=175, y=540, height=50)
txt.place(x=2, y=411, height=100, width=400)


tk_window.mainloop()
