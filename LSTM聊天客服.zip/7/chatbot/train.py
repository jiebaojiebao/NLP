
import json
import pickle
import nltk
#nltk.download('punkt')
#nltk.download('wordnet')
import numpy as np
from tensorflow.keras import Sequential
from tensorflow.keras.layers import Conv2D, Flatten, Dense, Dropout
from tensorflow.keras.optimizers import Adam

from nltk.stem import WordNetLemmatizer
lemmatizer = WordNetLemmatizer()
import random
from tensorflow.keras import Input


wordlist = []
#保存对话分类结果
category = []
#建立分词结果和意图属性之间的映射关系
question_scope_match = []
#定义停用词，停用词信息会被程序忽略
stop_word = ['?',',','.',';', ':','!','/','@','\'']



data_file = open('data/chatbot.json').read()
chatbot = json.loads(data_file)
#print("语料信息：\n",chatbot)


for chatword in chatbot['chatbot']:
    for word in chatword['input']:

        word_tokens = nltk.word_tokenize(word)
        #print("分词结果：",word_tokens)
        wordlist.extend(word_tokens)
        question_scope_match.append((word_tokens, chatword['category']))
        #print("提问内容与提问意图匹配结果：",question_scope_match)
        #建立分类列表信息
        if chatword['category'] not in category:
            category.append(chatword['category']) 
#转换成小写，词形还原处理，结果排序
wordlist = [lemmatizer.lemmatize(w) for w in wordlist if w not in stop_word]
print("提问内容汇总:",wordlist)
print("提问意图汇总:",category)

pickle.dump(wordlist, open('data/wordlist.pkl','wb'))
pickle.dump(category, open('data/category.pkl','wb'))


training = []
output = [0] * len(category)
for matches in question_scope_match:
     #初始化词袋模型
    bow = []
    #分词列表
    match = matches[0]
    #print("matches[0]:",matches[0])
    #print("matches[1]:",doc[1])
    #转换成小写后词形还原
    match = [lemmatizer.lemmatize(word) for word in match]
    #基于词袋模型匹配成功，则相应位置标识为1，否则标识为0
    for j in wordlist:
        if j in match:
            bow.append(1)
        else:
            bow.append(0)

    output_row = list(output)
    output_row[category.index(matches[1])] = 1

    training.append([bow, output_row])


#训练数据随机化处理，并保存为数组格式
random.shuffle(training)
training = np.array(training,dtype=object)
print("training data:",training)

data_x = list(training[:,0])
data_y = list(training[:,1])
print("生成训练数据x:",data_x,"生成训练数据y:",data_y)


# 创建三层模型
# 第一层包含256神经元
model = Sequential()
model.add(Input(shape=(len(data_x[0],))))
model.add(Dense(256, activation='sigmoid',use_bias=False,
    kernel_initializer='glorot_uniform',
    bias_initializer='zeros', kernel_regularizer=None,
    bias_regularizer=None, activity_regularizer=None, kernel_constraint=None,
    bias_constraint=None))
    
    
# 第二层包含128神经元
model.add(Dense(128, activation='sigmoid',use_bias=False,
    kernel_initializer='glorot_uniform',
    bias_initializer='zeros', kernel_regularizer=None,
    bias_regularizer=None, activity_regularizer=None, kernel_constraint=None,
    bias_constraint=None))
model.add(Dropout(0.3))




#创建输出结果
model.add(Dense(len(data_y[0]), activation='softmax',use_bias=False,
    kernel_initializer='glorot_uniform',
    bias_initializer='zeros', kernel_regularizer=None,
    bias_regularizer=None, activity_regularizer=None, kernel_constraint=None,
    bias_constraint=None))


optimizer = Adam()
model.compile(loss='categorical_crossentropy', optimizer=optimizer, metrics=['mae', 'accuracy'])

#根据数据训练模型 
model_fit = model.fit(np.array(data_x), np.array(data_y), epochs=500, batch_size=64, verbose=1,callbacks=None,validation_split=0.0,validation_data=None,shuffle=True,class_weight=None,sample_weight=None,
    initial_epoch=0,steps_per_epoch=None,validation_steps=None,validation_batch_size=None,validation_freq=1,
    max_queue_size=10,workers=1,use_multiprocessing=False)
    #保存训练结果
model.save('data/model.h5', model_fit)


